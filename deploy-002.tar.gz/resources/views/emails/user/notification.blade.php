<html lang="{{ app()->getLocale() }}" @if (\Helper::isLocaleRtl()) dir="rtl" @endif>
<head>
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
	<meta name="viewport" content="width=350px, user-scalable=yes">
	<style>
		#wrapper * { max-width: 650px !important; }
		p { margin:0 0 1.5em 0; }
		pre { font-family: Menlo, Monaco, monospace, sans-serif; padding: 0 0 1.6em 0; color:#333333; line-height:15px; }
		a { color:#3f8abf; text-decoration:none; }
	</style>
	<!--[if gte mso 12]>
		<style type="text/css">
			.tag {
				line-height: 0px !important;
				background-color: #ffffff; !important;
				font-size: 0px !important;
				padding: 0px !important;
				margin: 0px !important;
				width: 0px !important;
			}
		</style>
	<![endif]-->
</head>
<body bgcolor="#f8f9f9" style="-webkit-text-size-adjust:none; margin: 0;">
	@php $is_rtl = \Helper::isLocaleRtl(); @endphp
	<table bgcolor="#f8f9f9" cellspacing="0" border="0" cellpadding="0" width="100%" id="{{ \MailHelper::REPLY_SEPARATOR_NOTIFICATION }}" class="{{ \MailHelper::REPLY_SEPARATOR_NOTIFICATION }}" data-fs="{{ \MailHelper::REPLY_SEPARATOR_NOTIFICATION }}">
		<tr>
			<td>
				<table class="content" width="100%" border="0" cellspacing="0" cellpadding="0">
				    <tr>
				        <td height="45" valign="bottom"><p align="center" style="font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; font-size:12px; color:#B5B9BD; line-height:16px; margin:0;">{{ $mailbox->getReplySeparator() }}</p></td>
				    </tr>
				    <tr>
				        <td height="12"></td>
				    </tr>
				    <tr>
				        <td>
				            <table align="center" width="95%" border="0" cellspacing="0" cellpadding="0" style="max-width: 650px; margin: 0 auto;">
				                <tr>
				                    <td align="center">
                                        <p style="font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; font-size:14px; color:#B5B9BD; line-height:16px; margin:0; margin-bottom: 6px;">
                                        	[{{ $mailbox->name }}]
                                        </p>
				                        <p style="display:inline; font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; color:#444; line-height:22px; font-size:16px; margin:0; @if ($is_rtl) text-align: right; direction: rtl; unicode-bidi: plaintext; @endif">
                                            {{ __('Replying to this notification will email :name', ['name' => ($customer ? $customer->getFirstName(true) : '')]) }} (<a href="mailto:{{ $conversation->customer_email }}" style="color:#3f8abf; text-decoration:none;">{{ $conversation->customer_email ?? '' }}</a>)
                                            @if ($conversation->getCcArray())
                                            	<br/><small>CC: {{ implode(', ', $conversation->getCcArray()) }}</small>
                                            @endif
                                        </p>
				                    </td>
				                </tr>
				            </table>
				        </td>
				    </tr>
				    <tr>
				        <td height="12"></td>
				    </tr>
				</table>

				{{-- START header --}}
				<table id="wrapper" align="center" width="95%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" style="border: 1px solid #d4d9dd; max-width: 650px; border-bottom: 0; margin: 0 auto;">
					<tr>
						<td bgcolor="#ffffff" style="padding:1.5em 2em; border-bottom: 1px solid #dde3e7;">
							<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">
							    <tr>
							        <td colspan="2">
							            <p style="font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; line-height:15px; margin:0; font-size:12px; color:#a1a6ab; padding-bottom: 0.75em; @if ($is_rtl) text-align: right; direction: rtl; unicode-bidi: plaintext; @endif">
							            	@if (count($threads) == 1)
							            		{{ __('Received a new conversation') }}
							            	@else
								            	@if ($thread->action_type == App\Thread::ACTION_TYPE_STATUS_CHANGED)
			                                        {!! __h(":person marked as :status conversation", ['person' => '<strong>'.htmlspecialchars($thread->getCreatedBy()->getFullName(true)).'</strong>', 'status' => htmlspecialchars($thread->getStatusName())]) !!}
			                                    @elseif ($thread->action_type == App\Thread::ACTION_TYPE_USER_CHANGED)
				                                    <strong>@include('emails/user/thread_by')</strong>  
													{{ __("assigned to :person conversation", ['person' => $thread->getAssigneeName(false, $user)]) }}
			                                    @elseif ($thread->type == App\Thread::TYPE_NOTE)
			                                    	{!! __h(":person added a note to conversation", ['person' => '<strong>'.htmlspecialchars($thread->getCreatedBy()->getFullName(true)).'</strong>']) !!}
			                                    @else
			                                    	{!! __h(":person replied to conversation", ['person' => '<strong>'.htmlspecialchars($thread->getCreatedBy()->getFullName(true)).'</strong>']) !!}
			                                    @endif
			                                @endif
							            	<a href="{{ \Eventy::filter('email_notification.conv_url', $conversation->url(), $user) }}" style="color:#3f8abf; text-decoration:none;">#{{ $conversation->number }}</a></p>
							        </td>
							    </tr>
							    <tr>
							    	@if ($is_rtl)
										{{-- RTL Order: Subject on the right, Status on the left --}}
                                        <td align="left" valign="top">
                                            <table border="0" cellspacing="0" cellpadding="5" style="margin-top: 5px;">
                                                <tr>
                                                    <td height="10" bgcolor="{{ $conversation->getStatusColor() }}" style="color:#ffffff; font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; line-height:12px; font-size:12px; margin-top: 3px;border-radius: 2px;">{{ strtoupper($conversation->getStatusName()) }}</td>
                                                </tr>
                                            </table>
                                            @if ($conversation->user_id && $conversation->user)
                                                <table border="0" cellspacing="0" cellpadding="0">
                                                    <tr>
                                                        <td style="font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; color:#B5B9BD; line-height:16px; font-size:12px; padding-top: 8px;text-align:left;">
                                                            {{ __('Assigned to') }} {{ $conversation->user->getFullName() }}
                                                        </td>
                                                    </tr>
                                                </table>
                                            @endif
                                        </td>
                                        <td valign="top">
                                            <table border="0" cellspacing="0" cellpadding="0">
                                                <tr>
                                                    <td>
                                                        <h3 style="font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; color:#222222; line-height:25px; font-size:20px; margin:0; font-weight:normal; text-align: right; direction: rtl; unicode-bidi: plaintext;">{{ $conversation->subject }}</h3>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
							    	@else
							    		{{-- LTR Order: Status on the left, Subject on the right --}}
								        <td valign="top">
								            <table border="0" cellspacing="0" cellpadding="0">
								                <tr>
								                    <td>
								                        <h3 style="font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; color:#222222; line-height:25px; font-size:20px; margin:0; font-weight:normal;">{{ $conversation->subject ?? '' }}</h3>
								                    </td>
								                </tr>
								            </table>
								        </td>
								        <td align="right" valign="top">
								            <table border="0" cellspacing="0" cellpadding="5" style="margin-top: 5px;">
								                <tr>
								                    <td height="10" bgcolor="{{ $conversation->getStatusColor() }}" style="color:#ffffff; font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; line-height:12px; font-size:12px; margin-top: 3px;border-radius: 2px; {{--@if ($conversation->status == App\Conversation::STATUS_PENDING)border: 1px solid #ccc; color: #727d87;@endif--}}">{{ strtoupper($conversation->getStatusName()) }}</td>
								                </tr>
								            </table>
								            @if ($conversation->user_id && $conversation->user)
									            <table border="0" cellspacing="0" cellpadding="0">
									                <tr>
									                    <td style="font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; color:#B5B9BD; line-height:16px; font-size:12px; padding-top: 8px;text-align:right;">
									                        {{ __('Assigned to') }} {{ $conversation->user->getFullName() }}
									                    </td>
									                </tr>
									            </table>
									        @endif
								        </td>
								    @endif
							    </tr>
							</table>
						</td>
					</tr>
					{{-- END header --}}

	            	@foreach ($threads as $thread)

	            		@if ($thread->type == App\Thread::TYPE_LINEITEM)
	            			{{-- Line item --}}
	            			<tr>
								<td>
									<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#f8f9fa" style="border-bottom:1px solid #dde3e7;">
										<tr>
											<td style="padding: 0.75em 2em;">
												<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#f8f9fa">
													<tr>
														@if ($is_rtl)
															<td valign="top">
																<div style="font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; color:#b5b9bd; font-size:12px; line-height:16px; margin:0;" align="left">{{ App\User::dateFormat($thread->created_at, 'M j, H:i', $user) }}</div>
															</td>
															<td valign="top">
																<div style="{{-- display:inline; --}}font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; color:#b5b9bd; font-size:12px; line-height:16px; margin:0; text-align: right; direction: rtl; unicode-bidi: plaintext;">
																	{!! safe_raw_html($thread->getActionText('', true, false, $user, htmlspecialchars(view('emails/user/thread_by', ['thread' => $thread, 'user' => $user])->render()))) !!}
																</div>
															</td>
														@else
															<td valign="top">
																<div style="{{-- display:inline; --}}font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; color:#b5b9bd; font-size:12px; line-height:16px; margin:0;">
																	{!! safe_raw_html($thread->getActionText('', true, false, $user, htmlspecialchars(view('emails/user/thread_by', ['thread' => $thread, 'user' => $user])->render()))) !!}
																</div>
															</td>
															<td valign="top">
																<div style="font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; color:#b5b9bd; font-size:12px; line-height:16px; margin:0;">{{ App\User::dateFormat($thread->created_at, 'M j, H:i', $user) }}</div>
															</td>
														@endif
													</tr>
												</table>
											</td>
										</tr>
									</table>
								</td>
							</tr>
	            		@else
	            			{{-- Reply --}}
							<tr>
								<td>
									<table width="100%" border="0" cellspacing="0" cellpadding="0" style="border-bottom:1px solid #dde3e7;">
									    <tr>
									        <td style="padding: 2em;" bgcolor="@if ($thread->type == App\Thread::TYPE_MESSAGE){{ config('app.colors')['bg_user_reply'] }}@elseif ($thread->type == App\Thread::TYPE_NOTE){{ config('app.colors')['bg_note'] }}@else{{ 'ffffff' }}@endif">
									            <table width="100%" border="0" cellspacing="0" cellpadding="0">
									                <tr>
									                	@if ($is_rtl)
                                                            {{-- RTL Order: User name on the right, Date on the left --}}
                                                            <td valign="top">
                                                                <div style="font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; color:#B5B9BD; font-size:12px; line-height:18px; margin:0;" align="left">{{ App\User::dateFormat($thread->created_at, 'M j, H:i', $user) }}</div>
                                                            </td>
                                                            <td>
                                                                <h3 style="font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; font-size:17px; line-height:22px; margin:0 0 2px 0; font-weight:normal; text-align: right; direction: rtl; unicode-bidi: plaintext;">
                                                                    @include('emails.user._notification_thread_action', ['thread' => $thread])
                                                                </h3>
                                                            </td>
                                                        @else
                                                            {{-- LTR Order: Date on the right, User name on the left --}}
										                    <td>
										                        <h3 style="font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; font-size:17px; line-height:22px; margin:0 0 2px 0; font-weight:normal;">
										                        	@include('emails.user._notification_thread_action', ['thread' => $thread])
																</h3>
										                    </td>
										                    <td valign="top">
										                        <div style="font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; color:#B5B9BD; font-size:12px; line-height:18px; margin:0;" align="right">{{ App\User::dateFormat($thread->created_at, 'M j, H:i', $user) }}</div>
										                    </td>
										                @endif
									                </tr>
									                <tr>
									                    <td colspan="2" height="20">&nbsp;</td>
									                </tr>
									                <tr>
									                    <td colspan="2">
									                    	@if ($thread->isForward())
							                                    <div style="color: #b37100; background-color: #fff1cf; padding: 15px; margin-bottom: 20px; border: 1px solid #ffe19d; @if ($is_rtl) text-align: right; direction: rtl; unicode-bidi: plaintext; @endif">
							                                        {!! __h(':person forwarded this conversation. Forwarded conversation: :forward_child_conversation_number', [
							                                        'person' => htmlspecialchars(ucfirst($thread->getForwardByFullName())),
							                                        'forward_child_conversation_number' => '<a href="'.route('conversations.view', ['id' => $thread->getMetaFw(App\Thread::META_FORWARD_CHILD_CONVERSATION_ID)]).'">#'.htmlspecialchars($thread->getMetaFw(App\Thread::META_FORWARD_CHILD_CONVERSATION_NUMBER)).'</a>'
							                                        ]) !!}
							                                    </div>
							                                @endif
							                                @action('email_notification.before_body', $thread, $user, $conversation)
									                        <div style="font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; color:#444; font-size:14px; line-height:20px; margin:0; @if ($is_rtl) text-align: right; direction: rtl; unicode-bidi: plaintext; @endif">
																{!! safe_raw_html($thread->getCleanBody() ?? '') !!}
															</div>

															@if ($thread->has_attachments)
																<table cellspacing="0" cellpadding="6" @if ($is_rtl) width="100%" @endif>
																	<tr>
																		<td height="15">&nbsp;</td>
																	<tr>
																	<tr>
																		<td bgcolor="#f1f3f4" align="{{ $is_rtl ? 'right' : 'left' }}">
																			<p style="display:inline; margin:0; padding: 0 5px; line-height:18px; font-size:12px; font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; color:#494848; @if ($is_rtl) text-align: right; direction: rtl; unicode-bidi: plaintext; @endif">
																				<strong>{{ __('Attached:') }}</strong>
																				@foreach ($thread->attachments as $attachment)
																					<a href="{{ $attachment->url() }}" style="color:#3f8abf; text-decoration:none;">{{ $attachment->file_name ?? '' }}</a> <span style="color:#B5B9BD;">({{ $attachment->getSizeName() }})</span>@if (!$loop->last), &nbsp;@endif
																				@endforeach
																			</p>
																		</td>
																	</tr>
																</table>
															@endif
									                    </td>
									                </tr>
									            </table>
									        </td>
									    </tr>
									</table>
								</td>
							</tr>
	            		@endif

					@endforeach
	            </table>
			</td>
		</tr>
		{{-- footer --}}
		<tr>
			<td>
				<table align="center" bgcolor="#f8f9f9" width="95%" border="0" cellspacing="0" cellpadding="0" style="max-width: 650px; margin: 0 auto;">
					<tr>
						<td height="22"></td>
					</tr>
					<tr>
						<td align="center">
							<p style="display:inline; margin:0; padding:0; font-size:12px; font-family:Arial, 'Helvetica Neue', Helvetica, Tahoma, sans-serif; color:#B5B9BD; line-height: 22px;" align="center"><a href="{{ \Eventy::filter('email_notification.settings_url', route('users.notifications', ['id' => $user->id]), $user) }}" style="color:#B5B9BD;">{{ __('Notification Settings') }}</a>{{ \Eventy::action('email_notification.footer_links', $mailbox, $conversation, $threads) }} - <a href="{{ \Eventy::filter('email_notification.mailbox_url', $mailbox->url(), $user) }}" style="color:#B5B9BD;">{{ $mailbox->name }}</a></p>
						</td>
					</tr>
					<tr>
						<td height="22"></td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td height="0" style="font-size: 0px; line-height: 0px; color:#ffffff;">	                    	
				{{-- Addition to Message-ID header to detect relies --}}
				<div style="font-size: 0px; line-height: 0px; color:#ffffff !important;">{{ \MailHelper::getMessageMarker($headers['Message-ID']) }}</div>
			</td>
		</tr>
	</table>
	<div itemscope itemtype="http://schema.org/EmailMessage">
		<div itemprop="potentialAction" itemscope itemtype="http://schema.org/ViewAction">
			<link itemprop="target" href="{{ $conversation->url() }}"/>
			<meta itemprop="name" content="{{ __('Open Conversation') }}"/>
		</div>
		<meta itemprop="description" content="{{ __('Open this conversation in :app_name', ['app_name' => 'FreeScout']) }}"/>
	</div>
</body>
</html>
